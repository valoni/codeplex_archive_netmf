/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * Project: 9dof: Razor 9DoF AHRS firmware and NETMF drivers
 * Description:  This is a collection of files that allows for easy
 * NETMf integration with the  * Sparkfun 9DoF Razor IMU.
 *
 * Author(s):
 * Chris Seto <chris@chrisseto.com>
 * Christian V�llinger <zerov83@googlemail.com>
 * 
 */

namespace NineDofAhrs
{
	public interface IAhrs
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="roll"></param>
		/// <param name="pitch"></param>
		/// <param name="yaw"></param>
		void GetAttitude(out double roll, out double pitch, out double yaw);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="z"></param>
		void GetAnalogs(out double x, out double y, out double z);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="z"></param>
		void GetAcc(out double x, out double y, out double z);
	}
}
