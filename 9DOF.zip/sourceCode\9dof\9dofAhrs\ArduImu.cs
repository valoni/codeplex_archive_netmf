/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 *
 * Project: 9dof: Razor 9DoF AHRS firmware and NETMF drivers
 * Description:  This is a collection of files that allows for easy
 * NETMf integration with the  * Sparkfun 9DoF Razor IMU.
 *
 * Author(s):
 * Chris Seto <chris@chrisseto.com>
 * Christian V�llinger <zerov83@googlemail.com>
 * 
 */

using System;
using Microsoft.SPOT;
using System.IO.Ports;
using NineDofAhrs.Extensions;

namespace NineDofAhrs
{
	public class ArduImu : IAhrs
	{
		/// <summary>
		/// Serial port handle
		/// </summary>
		private readonly SerialPort serialHandle;

		/// <summary>
		/// 
		/// </summary>
		private readonly byte[] imuBuffer = new byte[30];

		/// <summary>
		/// Current IMU parser phase
		/// </summary>
		private enum imuState
		{
			ReadHeader1 = 0,
			ReadHeader2 = 1,
			ReadHeader3 = 2,
			ReadHeader4 = 3,
			ReadPayloadLength = 4,
			ReadMessageID = 5,
			ReadPayload = 6,
			ReadChecksum1 = 7,
			ReadChecksum2 = 8
		}

		/// <summary>
		/// Current state of the IMU parser
		/// </summary>
		private imuState imuStep = imuState.ReadHeader1;

		/// <summary>
		/// 
		/// </summary>
		private byte payloadLength = 0;

		/// <summary>
		/// 
		/// </summary>
		private byte payloadCounter = 0;

		/// <summary>
		/// Checksum A
		/// </summary>
		private byte ckA = 0;

		/// <summary>
		/// Checksum B
		/// </summary>
		private byte ckB = 0;

		/// <summary>
		/// 
		/// </summary>
		private byte imuCkA = 0;

		/// <summary>
		/// 
		/// </summary>
		private byte imuCkB = 0;

		/// <summary>
		/// 
		/// </summary>
		private int imuPayloadErrorCount;

		/// <summary>
		/// 
		/// </summary>
		private int imuChecksumErrorCount;

		/// <summary>
		/// 
		/// </summary>
		private int imuMessagesReceived;

		/// <summary>
		/// 
		/// </summary>
		public bool ImuOk;

		/// <summary>
		/// 
		/// </summary>
		public bool ImuAnalogsOk;

		/// <summary>
		/// 
		/// </summary>
		public double Roll;

		/// <summary>
		/// 
		/// </summary>
		public double Pitch;

		/// <summary>
		/// 
		/// </summary>
		public double Yaw;

		/// <summary>
		/// 
		/// </summary>
		public short AnalogX;

		/// <summary>
		/// 
		/// </summary>
		public short AnalogY;

		/// <summary>
		/// 
		/// </summary>
		public short AnalogZ;

		/// <summary>
		/// 
		/// </summary>
		public short AccX;

		/// <summary>
		/// 
		/// </summary>
		public short AccY;

		/// <summary>
		/// 
		/// </summary>
		public short AccZ;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="port"></param>
		public ArduImu(string port)
		{
			serialHandle = new SerialPort(port, 57600);
			serialHandle.ReadTimeout = 0;
			
			// If you open the port after you set the event you will endup with problems
			serialHandle.Open();
			serialHandle.DiscardInBuffer();

			serialHandle.DataReceived += PortDataReceived;
			serialHandle.ErrorReceived += PortErrorReceived;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void PortErrorReceived(object sender, SerialErrorReceivedEventArgs e)
		{
			Debug.Print("Error: " + e.EventType);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void PortDataReceived(object sender, SerialDataReceivedEventArgs e)
		{
			int numc = 0;
			byte messageNum = 0;
			byte data;

			numc = serialHandle.BytesToRead;
			if (numc > 0)
			{
				for (int i = 0; i < numc; i++)
				{	// Process bytes received
					data = serialHandle.ReadByte();

					//Normally we start from zero. This is a state machine
					switch (imuStep)
					{	 	
						//
						case imuState.ReadHeader1:

							if (data == 0x44)
								imuStep++; //First byte of data packet header is correct, so jump to the next step

							break;

						// Check if the second byte of the packet header is correct
						case imuState.ReadHeader2:
							if (data == 0x49)
								imuStep++;
							else
								imuStep = imuState.ReadHeader1;	
							break;

						// Check if the third byte of the packet header is correct
						case imuState.ReadHeader3:
							if (data == 0x59)
								imuStep++;
							else
								imuStep = imuState.ReadHeader1;
							break;

						// Check if the third byte of the packet header is correct. If it is,
						// the header is then complete
						case imuState.ReadHeader4:
							if (data == 0x64)
								imuStep++;
							else
								imuStep = imuState.ReadHeader1;
							break;

						// Read the length of the payload
						case imuState.ReadPayloadLength:
							payloadLength = data;
							checksum(payloadLength);
							imuStep++;

							if (payloadLength > 28)
							{
								imuStep = imuState.ReadHeader1;	 //Bad data, so restart to step zero and try again.		 
								payloadCounter = 0;
								ckA = 0;
								ckB = 0;
								imuPayloadErrorCount++;
							}
							break;

						// Figure out what data we are going to RX
						case imuState.ReadMessageID:
							messageNum = data;
							checksum(data);
							imuStep++;
							break;

						// Read payload
						case imuState.ReadPayload:
							// We stay in this state until we reach the payload_length
							imuBuffer[payloadCounter] = data;
							checksum(data);
							payloadCounter++;

							if (payloadCounter >= payloadLength)
								imuStep++;
							break;

						// Read the first checksum
						case imuState.ReadChecksum1:
							imuCkA = data;
							imuStep++;
							break;

						// Read the second Checksum, verify both checksums
						// and parse the payload
						case imuState.ReadChecksum2:
							imuCkB = data;

							// We end the IMU/GPS read...
							// Verify the received checksum with the generated checksum.. 
							if ((ckA == imuCkA) && (ckB == imuCkB))
							{
								// Figure out what we need to parse
								switch (messageNum)
								{
									// IMU
									case 0x02:
										imuJoinData();
										break;

									// GPS
									case 0x03:
										gpsJoinData();
										break;

									// IMU2
									case 0x04:
										imu2JoinData();
										break;

									// IMU analogs
									case 0x05:
										imuAnalogsJoinData();
										break;

									// No idea
									default:
										Debug.Print("Invalid message number = " + messageNum);
										break;
								}
							}
							else
							{
								// We have a bad checksum...

								Debug.Print("MSG Checksum error");
								imuChecksumErrorCount++;
							}

							// Reset for the next iteration
							imuStep = imuState.ReadHeader1;
							payloadCounter = 0;
							ckA = 0;
							ckB = 0;
							break;
					}
				}

			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="data"></param>
		private void checksum(byte data)
		{
			ckA += data;
			ckB += ckA;
		}

		/// <summary>
		/// 
		/// </summary>
		private void gpsJoinData()
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// 
		/// </summary>
		private void imu2JoinData()
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// 
		/// </summary>
		private void imuJoinData()
		{
			imuMessagesReceived++;
			int j = 0;

			//Storing IMU roll
			Roll = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]) / 100.0;

			//Storing IMU pitch
			Pitch = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]) / 100.0;

			//Storing IMU heading (yaw)
			Yaw = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]) / 100.0;

			ImuOk = true;
		}

		/// <summary>
		/// 
		/// </summary>
		private void imuAnalogsJoinData()
		{
			imuMessagesReceived++;
			int j = 0;

			// Analog x
			AnalogX = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]);
			// Analog y
			AnalogY = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]);
			// Analog z
			AnalogZ = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]);

			// Acc x
			AccX = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]);
			// Acc y
			AccY = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]);
			// Acc z
			AccZ = (short)((imuBuffer[j++] << 8) | imuBuffer[j++]);

			ImuAnalogsOk = true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="roll"></param>
		/// <param name="pitch"></param>
		/// <param name="yaw"></param>
		public void IAhrs.GetAttitude(out double roll, out double pitch, out double yaw)
		{
			roll = Roll;
			pitch = Pitch;
			yaw = Yaw;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="z"></param>
		public void IAhrs.GetAnalogs(out double x, out double y, out double z)
		{
			x = AnalogX;
			y = AnalogY;
			z = AnalogZ;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="z"></param>
		public void IAhrs.GetAcc(out double x, out double y, out double z)
		{
			x = AccX;
			y = AccY;
			z = AccZ;
		}
	}
}
