namespace ZealC02.Encoding
{
    using System.Text;

    public static class UTF8
    {
        public static byte[] GetBytes(string s)
        {
            return Encoding.UTF8.GetBytes(s);
        }

        public static int GetBytes(string s, int charIndex, int charCount, byte[] bytes, int byteIndex)
        {
            return System.Text.Encoding.UTF8.GetBytes(s, charIndex, charCount, bytes, byteIndex);
        }

        public static char[] GetChars(byte[] bytes)
        {
            return System.Text.Encoding.UTF8.GetChars(bytes);
        }

        public static char[] GetChars(byte[] bytes, int byteIndex, int byteCount)
        {
            return System.Text.Encoding.UTF8.GetChars(bytes, byteIndex, byteCount);
        }

        public static Decoder GetDecoder()
        {
            return System.Text.Encoding.UTF8.GetDecoder();
        }

        public static string GetString(byte[] bytes)
        {
            return new string(System.Text.Encoding.UTF8.GetChars(bytes));
        }

        public static string GetString(byte[] bytes, int index, int count)
        {
            return new string(System.Text.Encoding.UTF8.GetChars(bytes, index, count));
        }
    }
}
