﻿namespace ZealC02
{
    using System.IO.Ports;
    using System.Threading;
    using Microsoft.SPOT;

    public class Program
    {
        public static void Main()
        {
            var zeal = new ZealModule(Serial.COM1, 9600, Parity.None, 8, StopBits.One);

            zeal.NewLine = "\r\n";
            zeal.Open();

            zeal.TraceWriteLine("@@@" + Commands.Disconnect);

            zeal.TraceWriteLine("BTLT0006F7AFD492"); //Radi address

            zeal.TraceWriteLine("BTC");

            if (zeal.ReadLine() == ResultCode.CONN)
            {
                zeal.TraceWriteLine("YAMA");
            }

            zeal.TraceWriteLine("RSV");
            zeal.TraceWriteLine("RHR");
            zeal.TraceWriteLine("RPO");
            zeal.TraceWriteLine("RCD");
            zeal.TraceWriteLine("RDC");

            int count = 0;
            while (true)
            {
                Thread.Sleep(1000);
                Debug.Print("Iteration: " + count++);
                zeal.TraceWriteLine("RMS");
            }
        }
    }
}
