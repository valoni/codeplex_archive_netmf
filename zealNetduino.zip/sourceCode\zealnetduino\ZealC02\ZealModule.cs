﻿namespace ZealC02
{
    using System.IO.Ports;

    public enum ConnectionStatus
    {
        Connected = 0,
        Disconnected = 1
    }

    public enum Mode
    {
        CommandMode = 0,
        DataMode = 1
    }

    public class ConnectionStatusEventArgs
    {
        public ConnectionStatusEventArgs(ConnectionStatus s) { Status = s; }
        public ConnectionStatus Status { get; private set; }
    }

    public class ZealModule : SerialPortEx   
    {                
        public delegate void ConnectionStatusEventHanlder(object sender, ConnectionStatusEventArgs e);
        
        public event ConnectionStatusEventHanlder ConnectionStatusChanged;

        protected virtual void RaiseConnectionStatusEvent(ConnectionStatus status)
        {
            if (ConnectionStatusChanged != null)
                ConnectionStatusChanged(this, new ConnectionStatusEventArgs(status));
        }
                
        /// <summary>
        /// Create a new instance of the Zeal-C02 module class and open a connection
        /// using the specified connection setting.
        /// </summary>
        /// <param name="port">Serial port to use to talk to the Bluetooth device.</param>
        /// <param name="baudRate">Baud rate for the device.</param>
        /// <param name="parity">Parity settings for the device.</param>
        /// <param name="dataBits">Number of data bits for the device.</param>
        /// <param name="stopBits">Number of stop bits for the device.</param>
        public ZealModule(string port, int baudRate, Parity parity, int dataBits, StopBits stopBits)
            : base(port, baudRate, parity, dataBits, stopBits)
        {
        }
    }
}
