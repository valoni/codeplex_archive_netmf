﻿namespace ZealC02
{
    using System;
    using Microsoft.SPOT;

    public class ResultCode
    {
        /// <summary>
        /// コマンド受付
        /// </summary>
        public const string ACKN = "ACKN\r\n";

        /// <summary>
        /// Bluetooth接続確立
        /// </summary>
        public const string CONN = "CONN\r\n";

        /// <summary>
        /// 切断
        /// </summary>
        public const string DISC = "DISC\r\n";

        /// <summary>
        /// 接続相手をみつけることができない（※2）
        /// Can not find the connection partner 
        /// </summary>
        public const string E300 = "E300\r\n";
    }
}
