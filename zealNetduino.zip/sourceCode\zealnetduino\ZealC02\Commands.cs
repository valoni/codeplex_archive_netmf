﻿namespace ZealC02
{
    public class Commands
    {
        /// <summary>
        /// スレーブ側としてスキャン状態開始（SPP）
        /// Start as the slave side scan state (SPP).
        /// </summary>
        public const string Slave = "BTA";

        /// <summary>
        /// Bluetooth connection starts running as the master
        /// </summary>
        public const string Connect = "BTC";

        /// <summary>
        /// 接続切断、またはスキャン状態の解除
        /// Disconnect or cancel the scan state.
        /// </summary>
        public const string Disconnect = "BTD";
                
        public const string Escape = "@@@";
        
        /// <summary>
        /// エスケープ状態からの復帰
        /// Return from command mode.
        /// </summary>
        public const string ReturnToCommandMode = "BTR";
    }
}
