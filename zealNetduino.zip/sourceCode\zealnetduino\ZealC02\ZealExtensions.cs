namespace ZealC02
{
    using Microsoft.SPOT;

    public static class ZealExtensions
    {
        public static void TraceWriteLine(this ZealModule module, string command)
        {
            Debug.Print("Sending: " + command);
            module.WriteLine(command);
            var response = module.ReadLine();
            Debug.Print(response);
        }
    }
}
