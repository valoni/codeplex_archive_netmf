#include "touchpanel_stubs_functions.cpp"
#include "touchpanel_stubs_config.cpp"
