////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Microsoft Corporation.  All rights reserved.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "tinyhal.h"
#include "..\..\..\..\..\GHI\Drivers\FSMC\FT1505_LCD\LCD.h"

//--//

#define N18 1
#define GAMEO 2

#define ORIENTATION_ROT_0 0
#define ORIENTATION_ROT_90 1
#define ORIENTATION_ROT_180 2
#define ORIENTATION_ROT_270 3

SPI_CONFIGURATION g_SpecialDisplayConfigSPI = { GPIO_PIN_NONE, FALSE, FALSE, FALSE, FALSE, 0, 0, 0, 0, { GPIO_PIN_NONE, FALSE } };
INT32 g_SpecialDisplayConfigType = -1;
INT32 g_SpecialDisplayConfigOrientation = ORIENTATION_ROT_0;
INT32 g_SpecialDisplayConfigBPP = -1;
INT32 g_SpecialDisplayConfigRSPin = GPIO_PIN_NONE;

static void Swap(UINT8* a, UINT8* b)
{
	UINT8 temp = *a;
	*a = *b;
	*b = temp;
}

static void SetN18DrawWindow(int x, int y, int width, int height)
{
	if (g_SpecialDisplayConfigRSPin != GPIO_PIN_NONE)
	{
		CPU_GPIO_EnableOutputPin(g_SpecialDisplayConfigRSPin, FALSE);

		UINT8 command;
		UINT16 xBounds[2] = {x, x + width - 1};
		UINT16 yBounds[2] = {y, y + height - 1};
		
		Swap((UINT8*)xBounds + 0, (UINT8*)xBounds + 1);
		Swap((UINT8*)xBounds + 2, (UINT8*)xBounds + 3);
		Swap((UINT8*)yBounds + 0, (UINT8*)yBounds + 1);
		Swap((UINT8*)yBounds + 2, (UINT8*)yBounds + 3);

		command = 0x2A;
		CPU_GPIO_SetPinState(g_SpecialDisplayConfigRSPin, FALSE);
		CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, &command, 1, NULL, 0, 0);
		CPU_GPIO_SetPinState(g_SpecialDisplayConfigRSPin, TRUE);
		CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, (UINT8*)xBounds, 4, NULL, 0, 0);
			
		command = 0x2B;
		CPU_GPIO_SetPinState(g_SpecialDisplayConfigRSPin, FALSE);
		CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, &command, 1, NULL, 0, 0);
		CPU_GPIO_SetPinState(g_SpecialDisplayConfigRSPin, TRUE);
		CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, (UINT8*)yBounds, 4, NULL, 0, 0);
			
		command = 0x2C;
		CPU_GPIO_SetPinState(g_SpecialDisplayConfigRSPin, FALSE);
		CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, &command, 1, NULL, 0, 0);
		CPU_GPIO_SetPinState(g_SpecialDisplayConfigRSPin, TRUE);
	}
}

INT8 LCD_SetSpecialConfig(INT32 key, INT32 value)
{
	switch (key)
	{
		case 1: //Display Type
			if (value != N18 && value != GAMEO)
				return 0;

			g_SpecialDisplayConfigType = value;

			return 1;

		case 2: //Display BPP
			if (value != 7 && value != 8)
				return 0;

			g_SpecialDisplayConfigBPP = value;

			return 1;

		case 3: //Display Orientation
			if (value != ORIENTATION_ROT_0 && value != ORIENTATION_ROT_90 && value != ORIENTATION_ROT_180 && value != ORIENTATION_ROT_270)
				return 0;

			g_SpecialDisplayConfigOrientation = value;

			return 1;

		case 4: //Display Pin
			g_SpecialDisplayConfigRSPin = value;

			return 1;
		
		//SPI Configuration
		case 5: g_SpecialDisplayConfigSPI.DeviceCS = (GPIO_PIN)value; return 1;
		case 6: g_SpecialDisplayConfigSPI.CS_Active = (BOOL)value; return 1;
		case 7: g_SpecialDisplayConfigSPI.MSK_IDLE = (BOOL)value; return 1;
		case 8: g_SpecialDisplayConfigSPI.MSK_SampleEdge = (BOOL)value; return 1;
		case 9: g_SpecialDisplayConfigSPI.Clock_RateKHz = (UINT32)value; return 1;
		case 10: g_SpecialDisplayConfigSPI.CS_Setup_uSecs = (UINT32)value; return 1;
		case 11: g_SpecialDisplayConfigSPI.CS_Hold_uSecs = (UINT32)value; return 1;
		case 12: g_SpecialDisplayConfigSPI.SPI_mod = (UINT32)value; return 1;
		case 13: g_SpecialDisplayConfigSPI.BusyPin.Pin = (GPIO_PIN)value; return 1;
		case 14: g_SpecialDisplayConfigSPI.BusyPin.ActiveState = (BOOL)value; return 1;

		default:
			return 0;
	}
}

BOOL LCD_Initialize()
{
	NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return TRUE;
}

BOOL LCD_Uninitialize()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return TRUE;
}

void LCD_Clear()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
}

void LCD_BitBltEx(int srcX, int srcY, int width, int height, UINT32 data[])
{
	NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
	GLOBAL_LOCK(irq);
	
	UINT8* u8 = (UINT8*)data;
	UINT16* u16 = (UINT16*)data;

	int orientation = g_SpecialDisplayConfigOrientation;
	int countI, startI, stepI, countJ, startJ, stepJ;
	UINT16 windowX, windowY, windowWidth, windowHeight;
	int a, b, i, j, *x, *y;

	//To align the GameO's orientation with the N18 so they can share the same parameter setup.
	if (g_SpecialDisplayConfigType == GAMEO)
		orientation = (orientation + 3) % 4;
	
	if (orientation == ORIENTATION_ROT_0)
	{
		windowX = srcX; windowY = srcY; windowWidth = width; windowHeight = height;
		countI = height; startI = srcY; stepI = 1;
		countJ = width; startJ = srcX; stepJ = 1;
		x = &j; y = &i;
	}
	else if (orientation == ORIENTATION_ROT_90)
	{
		windowX = srcY; windowY = LCD_GetWidth() - srcX - width; windowWidth = height; windowHeight = width;
		countI = width; startI = srcX + width - 1; stepI = -1;
		countJ = height; startJ = srcY; stepJ = 1;
		x = &i; y = &j;
	}
	else if (orientation == ORIENTATION_ROT_180)
	{
		windowX = LCD_GetWidth() - srcX - width; windowY = LCD_GetHeight() - srcY - height; windowWidth = width; windowHeight = height;
		countI = height; startI = srcY + height - 1; stepI = -1;
		countJ = width; startJ = srcX + width - 1; stepJ = -1;
		x = &j; y = &i;
	}
	else if (orientation == ORIENTATION_ROT_270)
	{
		windowX = LCD_GetHeight() - srcY - height; windowY = srcX; windowWidth = height; windowHeight = width;
		countI = width; startI = srcX; stepI = 1;
		countJ = height; startJ = srcY + height - 1; stepJ = -1;
		x = &i; y = &j;
	}

	if (g_SpecialDisplayConfigType == N18)
	{
		for (int i = 0; i < LCD_GetWidth() * LCD_GetHeight() * 2; i += 2)
			Swap(u8 + i, u8 + i + 1);
			
		SetN18DrawWindow(windowX, windowY, windowWidth, windowHeight);
		
		//Shortcut for data that can be written straight out as is for maximum performance
		if (srcX == 0 && srcY == 0 && width == LCD_GetWidth() && height == LCD_GetHeight() && g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_0)
		{
			CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, u8, LCD_GetWidth() * LCD_GetHeight() * 2, NULL, 0, 0);
		}
		else
		{
			for (a = 0, i = startI; a < countI; a++, i += stepI)
				for (b = 0, j = startJ; b < countJ; b++, j += stepJ)
					CPU_SPI_nWrite8_nRead8(g_SpecialDisplayConfigSPI, u8 + *y * LCD_GetWidth() * 2 + *x * 2, 2, NULL, 0, 0);
		}
		
		for (int i = 0; i < (LCD_GetWidth() * LCD_GetHeight() * 2); i += 2)
			Swap(u8 + i, u8 + i + 1);
	}
	else if (g_SpecialDisplayConfigType == GAMEO)
	{
		LCD_SetDrawingWindow(windowX * 2, windowY * 2, windowWidth * 2, windowHeight * 2);
		
		for (a = 0, i = startI; a < countI; a++, i += stepI)
		{
			for (b = 0, j = startJ; b < countJ; b++, j += stepJ)
			{
				LCD_WriteData(u16[*y * LCD_GetWidth() + *x]);
				LCD_WriteData(u16[*y * LCD_GetWidth() + *x]);
			}
			for (b = 0, j = startJ; b < countJ; b++, j += stepJ)
			{
				LCD_WriteData(u16[*y * LCD_GetWidth() + *x]);
				LCD_WriteData(u16[*y * LCD_GetWidth() + *x]);
			}
		}
	}
}

void LCD_BitBlt( int width, int height, int widthInWords, UINT32 data[], BOOL fUseDelta )
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
}

void LCD_WriteChar( unsigned char c, int row, int col )
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
}

void LCD_WriteFormattedChar( unsigned char c )
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
}

INT32 LCD_GetWidth()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();

	if (g_SpecialDisplayConfigType == N18)
		return g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_0 || g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_180 ? 128 : 160;
	else if (g_SpecialDisplayConfigType == GAMEO)
		return g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_0 || g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_180 ? 160 : 120;
	else
		return 0;
}

INT32 LCD_GetHeight()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();

	if (g_SpecialDisplayConfigType == N18)
		return g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_0 || g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_180 ? 160 : 128;
	else if (g_SpecialDisplayConfigType == GAMEO)
		return g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_0 || g_SpecialDisplayConfigOrientation == ORIENTATION_ROT_180 ? 120 : 160;
	else
		return 0;
}

INT32 LCD_GetBitsPerPixel()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return 16;
}

UINT32 LCD_GetPixelClockDivider()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return 0;
}
INT32 LCD_GetOrientation()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return 0;
}
void LCD_PowerSave( BOOL On )
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
}

UINT32* LCD_GetFrameBuffer()
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return NULL;
}

UINT32 LCD_ConvertColor(UINT32 color)
{
    NATIVE_PROFILE_HAL_DRIVERS_DISPLAY();
    return color;
}


//--//


