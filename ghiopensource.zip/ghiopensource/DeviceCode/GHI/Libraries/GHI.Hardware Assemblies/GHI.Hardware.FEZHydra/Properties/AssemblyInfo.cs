﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("GHI.Hardware.FEZHydra")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("GHI Electronics")]
[assembly: AssemblyProduct("GHI.Hardware.FEZHydra")]
[assembly: AssemblyCopyright("Copyright © GHI Electronics 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
//[assembly: AssemblyVersion("4.2.6.0")]
//[assembly: AssemblyFileVersion("4.2.6.0")]
