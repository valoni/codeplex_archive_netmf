//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#ifndef _HAL_GHI_OSHW_HARDWARE_LCDCONTROLLER_H_
#define _HAL_GHI_OSHW_HARDWARE_LCDCONTROLLER_H_

namespace GHI
{
    namespace OSHW
    {
        namespace Hardware
        {
            struct LCDController
            {
                // Helper Functions to access fields of managed object
                // Declaration of stubs. These functions are implemented by Interop code developers
                static INT8 Set( UINT32 param0, UINT32 param1, INT8 param2, INT8 param3, INT8 param4, INT8 param5, INT8 param6, INT8 param7, UINT8 param8, UINT8 param9, UINT8 param10, UINT8 param11, UINT8 param12, UINT8 param13, UINT32 param14, HRESULT &hr );
            };
        }
    }
}
#endif  //_HAL_GHI_OSHW_HARDWARE_LCDCONTROLLER_H_
