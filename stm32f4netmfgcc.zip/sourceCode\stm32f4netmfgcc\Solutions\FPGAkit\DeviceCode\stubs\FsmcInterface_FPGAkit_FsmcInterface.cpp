//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "FsmcInterface.h"
#include "FsmcInterface_FPGAkit_FsmcInterface.h"

using namespace FPGAkit;


UINT16 FsmcInterface::get_Item( CLR_RT_HeapBlock* pMngObj, UINT32 offset, HRESULT &hr )
{
		if (offset >= FSMC_MAX_OFFSET) {
				hr = CLR_E_OUT_OF_RANGE;
				return 0;
		}
		
		volatile UINT16* fpga_data = (volatile UINT16*) FSMC_BASE_ADDRESS;
		return fpga_data[offset];
}


void FsmcInterface::set_Item( CLR_RT_HeapBlock* pMngObj, UINT32 offset, UINT16 new_data, HRESULT &hr )
{
		if (offset >= FSMC_MAX_OFFSET) {
				hr = CLR_E_OUT_OF_RANGE;
				return 0;
		}

		volatile UINT16* fpga_data = (volatile UINT16*) FSMC_BASE_ADDRESS;
		fpga_data[offset] = new_data;
}

