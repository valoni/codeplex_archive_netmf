//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "fsmcIface2.h"
#include "fsmcIface2_fsmcIface2_FsmcMemory.h"

using namespace fsmcIface2;

const UINT32 FsmcMemory::FSMC_BASE_ADDR   = 0x60000000;
const UINT32 FsmcMemory::FSMC_MAX_OFFSET  = 0x0000ffff;

UINT16 FsmcMemory::readUint16( CLR_RT_HeapBlock* pMngObj, UINT16 offset, HRESULT &hr )
{
    volatile UINT16* fsmcData = (volatile UINT16*) FSMC_BASE_ADDR;
    return fsmcData[offset];
}

void FsmcMemory::writeUint16( CLR_RT_HeapBlock* pMngObj, UINT16 offset, UINT16 newdata, HRESULT &hr )
{
    volatile UINT16* fsmcData = (volatile UINT16*) FSMC_BASE_ADDR;
		fsmcData[offset] = newdata;
}

void FsmcMemory::readBlock( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT16 buf, UINT16 offset, HRESULT &hr )
{
		// check whether the buffer size extends beyond the fsmc address space
		if (buf.GetSize() > (FSMC_MAX_OFFSET - offset)) {
				hr = CLR_E_OUT_OF_RANGE;
				return;
		}

    volatile UINT16* fsmcData = (volatile UINT16*) FSMC_BASE_ADDR;
				
		// copy the fsmc address space to the buffer
		UINT32 i;
		for ( i=0; i<buf.GetSize(); i++ ) {
		    UINT16 dat = fsmcData[ offset + i ];
				buf.SetValue(i, dat);
		}
}

void FsmcMemory::writeBlock( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT16 buf, UINT16 offset, HRESULT &hr )
{
		// check whether the buffer size extends beyond the fsmc address space
		if (buf.GetSize() > (FSMC_MAX_OFFSET - offset)) {
				hr = CLR_E_OUT_OF_RANGE;
				return;
		}

    volatile UINT16* fsmcData = (volatile UINT16*) FSMC_BASE_ADDR;
				
		// copy the buffer onto the FSMC external memory bus
		UINT32 i;
		for ( i=0; i<buf.GetSize(); i++ ) {
		    fsmcData[ offset + i ] = buf.GetValue(i);
		}		
}

