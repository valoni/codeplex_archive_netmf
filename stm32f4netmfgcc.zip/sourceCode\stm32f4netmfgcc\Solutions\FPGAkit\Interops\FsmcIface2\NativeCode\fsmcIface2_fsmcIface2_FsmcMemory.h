//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#ifndef _FSMCIFACE2_FSMCIFACE2_FSMCMEMORY_H_
#define _FSMCIFACE2_FSMCIFACE2_FSMCMEMORY_H_

namespace fsmcIface2
{
    struct FsmcMemory
    {
        // Constants
        static const UINT32 FSMC_BASE_ADDR;
        static const UINT32 FSMC_MAX_OFFSET;
				
				// Helper Functions to access fields of managed object
        // None
        
        // Declaration of stubs. These functions are implemented by Interop code developers
        static UINT16 readUint16( CLR_RT_HeapBlock* pMngObj, UINT16 offset, HRESULT &hr );
        static void writeUint16( CLR_RT_HeapBlock* pMngObj, UINT16 offset, UINT16 newdata, HRESULT &hr );
        static void readBlock( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT16 buf, UINT16 offset, HRESULT &hr );
        static void writeBlock( CLR_RT_HeapBlock* pMngObj, CLR_RT_TypedArray_UINT16 buf, UINT16 offset, HRESULT &hr );
    };
}
#endif  //_FSMCIFACE2_FSMCIFACE2_FSMCMEMORY_H_
