//-----------------------------------------------------------------------------
//
//                   ** WARNING! ** 
//    This file was generated automatically by a tool.
//    Re-running the tool will overwrite this file.
//    You should copy this file to a custom location
//    before adding any customization in the copy to
//    prevent loss of your changes when the tool is
//    re-run.
//
//-----------------------------------------------------------------------------


#include "FsmcIface.h"
#include "FsmcIface_FPGAkit_FsmcMemory.h"

using namespace FPGAkit;

const UINT32 FsmcMemory::FSMC_BASE_ADDR = 0x60000000;


UINT16 FsmcMemory::read( CLR_RT_HeapBlock* pMngObj, UINT16 offset, HRESULT &hr )
{
    volatile UINT16 *fsmcData = (volatile UINT16 *)FSMC_BASE_ADDR;
    return fsmcData[offset];
}

void FsmcMemory::write( CLR_RT_HeapBlock* pMngObj, UINT16 offset, UINT16 newdata, HRESULT &hr )
{
    volatile UINT16 *fsmcData = (volatile UINT16 *)FSMC_BASE_ADDR;
    fsmcData[offset] = newdata;
}

