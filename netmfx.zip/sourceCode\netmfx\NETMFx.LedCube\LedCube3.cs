using Microsoft.SPOT.Hardware;

namespace NETMFx.LedCube
{
    /// <summary>
    /// 
    /// </summary>

    public class LedCube3 : LedCube
    {
        public LedCube3( byte size, Cpu.Pin[] levelPins, Cpu.Pin[] ledPins, CubeOrientations orientation = CubeOrientations.ZPos) 
            : base(size, levelPins, ledPins, orientation)
        {
        }
    }
}
