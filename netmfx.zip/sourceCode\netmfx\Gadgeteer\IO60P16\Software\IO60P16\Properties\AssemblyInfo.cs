﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GTM.GHIElectronics.IO60P16")]
[assembly: AssemblyDescription("Driver for IO60P16 module made by GHI Electronics for Microsoft .NET Gadgeteer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("GHI Electronics")]
[assembly: AssemblyProduct("IO60P16")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// This is the assembly version.  It is often useful to keep this constant between major releases where the API changes
// since a dll relying on this dll will need to be recompiled if this changes.
// Suggestion: use a version number X.Y.0.0 where X and Y indicate major version numbers.
[assembly: AssemblyVersion("4.1.0.0")]

// These numbers must be changed whenever a new version of this dll is released, to allow upgrades to proceed correctly.
// Suggestion: Use a version number X.Y.Z.0 where X.Y.Z is the same as the installer version found in Setup\common.wxi
[assembly: AssemblyFileVersion("4.1.0.0")]
[assembly: AssemblyInformationalVersion("4.1.0.0")]
