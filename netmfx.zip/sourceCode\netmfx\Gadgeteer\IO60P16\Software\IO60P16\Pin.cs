using System;
using Microsoft.SPOT;

namespace Gadgeteer.Modules.GHIElectronics.IO60P16
{
    public static class Pin
    {
        public static IOPin Input;
        public static IOPin Output;
        public static IOPin Tristate;
        public static PwmPin Pwm;
    }
}
