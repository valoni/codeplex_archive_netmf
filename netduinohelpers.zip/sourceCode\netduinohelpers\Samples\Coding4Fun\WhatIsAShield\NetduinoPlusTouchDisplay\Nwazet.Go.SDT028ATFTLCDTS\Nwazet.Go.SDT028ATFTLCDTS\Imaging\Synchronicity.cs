namespace Nwazet.Go.Imaging {
    public enum Synchronicity {
        Asynchronous,
        Synchronous
    }
}