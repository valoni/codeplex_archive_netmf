namespace netduino.helpers.Fun {
    public delegate void GameLoop();
}
